/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class CalculatePrice {
    private double finalAmt;
    public double calculatePrice(double amount, String item){
        
        ExcelPrices ex = new ExcelPrices();
        ex.priceSetter();
        switch(item.toLowerCase()){
            case "8oz", "sparkle" -> finalAmt = amount * ex.eightOz;
                    case "cobra y/g" -> finalAmt = amount * ex.cobra;
                    case "cobra r" -> finalAmt = amount * ex.cobraRed;
                    case "12oz" -> finalAmt = amount * ex.twelveOz;
                    case "rc", "lemon" -> finalAmt = amount * ex.rc;
                    case "mdw - 12oz" -> finalAmt = amount * ex.mdw12Oz;
                    case "gatorade" -> finalAmt = amount * ex.gatorade;
                    case "pepsi" -> finalAmt = amount * ex.pepsi;
                    case "mdw-8oz" -> finalAmt = amount * ex.mdw8oz;
                    case "magnolia" -> finalAmt = amount * ex.magnolia;
                    case "mismo" -> finalAmt = amount * ex.mismo;
                    case "swakto" -> finalAmt = amount * ex.swakto;
                    case "minute-maid" -> finalAmt = amount * ex.minuteMaid;
                    case "c2" -> finalAmt = amount * ex.c2price;
                    case "v-shake" -> finalAmt = amount * ex.vshake;
                    case "vita" -> finalAmt = amount * ex.vchoco;
                    case "pepsi litro" -> finalAmt = amount * ex.pepsiLitro;
                    case "litro" -> finalAmt = amount * ex.litro;
                    case "7up/mdw litro" -> finalAmt = amount * ex.sevenUp;
                    case "j5" -> finalAmt = amount * ex.j5;
                    case "kasalo" -> finalAmt = amount * ex.kasalo;
                    case "r2" -> finalAmt = amount * ex.r2;
                    case "t-ice" -> finalAmt = amount * ex.tice;
                    case "j2","soda fam" -> finalAmt = amount * ex.lemonMega;
                    case "jumbo" -> finalAmt = amount * ex.jumbo;
                    case "grande" -> finalAmt = amount * ex.grande;
                    case "rh-500" -> finalAmt = amount * ex.rh500;
                    case "stallion" -> finalAmt = amount * ex.stallion;
                    case "pilsen" -> finalAmt = amount * ex.pilsen;
                    case "sml" -> finalAmt = amount * ex.light;
                    case "flavored" -> finalAmt = amount * ex.lightFlavored;

                    case "jamaica" -> finalAmt = amount * ex.jamaica;
                    case "t65 - flat" -> finalAmt = amount * ex.t65Flat;
                    case "5yrs flat" -> finalAmt = amount * ex.fiveYrsFlat;
                    case "t65 long" -> finalAmt = amount * ex.t65Long;
                    case "5-yrs long" -> finalAmt = amount * ex.fiveYrsLong;

                    case "1.5l" -> finalAmt = amount * ex.onePointFiveLiters;
                    case "qute" -> finalAmt = amount * ex.qute;
                    case "w-330" -> finalAmt = amount * ex.w330;
                    case "w-500" -> finalAmt = amount * ex.w500;
                    case "ab-6000" -> finalAmt = amount * ex.ab6000;
                    case "w-7000" -> finalAmt = amount * ex.w6000;
                    case "astig" -> finalAmt = amount * ex.astig;
                    case "1.25l" -> finalAmt = amount * ex.point25;
                    default -> System.out.println("properly choose one");
        }
        return finalAmt;
    }
}
