
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class GetCustomerDeposits {
    private String botValue;
    private String shellValue;
    private String fcValue;
    private String formulaValue;
    
    
    public void getCusDeposit(int row){
        SetSelectedFile sf = new SetSelectedFile();
        String excelFilePath = sf.getFilePath();
        
        try{
            
            FileInputStream inputStream = new FileInputStream(excelFilePath);

            Workbook workbook = WorkbookFactory.create(inputStream);

            Sheet sheet = workbook.getSheetAt(0);
            
            Row rowSelect = sheet.getRow(row);
            Cell cellBot = rowSelect.getCell(58);

            if (cellBot.toString().isEmpty()) {
                botValue = "0";
            } else {
                botValue = cellBot.toString();
            }

            Cell cellShell = rowSelect.getCell(57);
            if (cellShell.toString().isEmpty()) {
                shellValue = "0";
            } else {
                shellValue = cellShell.toString();
            }

            Cell cellFC = rowSelect.getCell(56);
            if (cellFC.toString().isEmpty()) {
                fcValue = "0";
            } else {
                fcValue = cellFC.toString();
            }

            Cell formulaCell = rowSelect.getCell(59);
            if (formulaCell.toString().isEmpty()) {
               formulaValue = "0";
            } else {
                formulaValue = formulaCell.getCellFormula();
            }
            
            
            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
        }
        catch(IOException | EncryptedDocumentException ex){
             ex.printStackTrace();
        }
    }

    public String getBotValue() {
        return botValue;
    }

    public String getShellValue() {
        return shellValue;
    }

    public String getFcValue() {
        return fcValue;
    }

    public String getFormulaValue() {
        return formulaValue;
    }
    
}
