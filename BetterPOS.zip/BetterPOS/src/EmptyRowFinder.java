
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class EmptyRowFinder {
    private int emptyRow;
    EmptyRowFinder(int startPoint){
        
        int index = 0;
        try {
            SetSelectedFile sf = new SetSelectedFile();
            String excelFilePath = sf.getFilePath();
            FileInputStream inputStream = new FileInputStream(excelFilePath);
            Workbook workbook = WorkbookFactory.create(inputStream);

            Sheet sheet = workbook.getSheetAt(0);
            while (index == 0) {
                Row readRow = sheet.getRow(startPoint);
                Cell readCell = readRow.getCell(1);

                if (readCell.toString().isEmpty()) {
                    index = 1;
                } else {
                    startPoint++;
                }
            }
            emptyRow = startPoint;

            inputStream.close();

            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();


        } catch (IOException | EncryptedDocumentException ex) {
            ex.printStackTrace();
        }
    }
    public int getEmptyRow(){
        return emptyRow;
    }
}
