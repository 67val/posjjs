
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class DeleteCustomerData {
    public void deleteRow(int rowSelected){
        SetSelectedFile sf = new SetSelectedFile();
        String excelFilePath = sf.getFilePath();
        
        try {
            FileInputStream inputStream = new FileInputStream(excelFilePath);
            Workbook workbook = WorkbookFactory.create(inputStream);

            CellStyle style = workbook.createCellStyle();
            style.setBorderBottom(BorderStyle.THIN);
            style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style.setBorderRight(BorderStyle.THIN);
            style.setRightBorderColor(IndexedColors.BLACK.getIndex());
            style.setBorderTop(BorderStyle.THIN);
            style.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style.setBorderLeft(BorderStyle.THIN);
            style.setTopBorderColor(IndexedColors.BLACK.getIndex());

            Sheet sheet = workbook.getSheetAt(0);

            Row row = sheet.getRow(rowSelected);

            Cell cell2 = row.createCell(5);
            cell2.setCellValue("i");

            for (int i = 1; i < 66; i++) {
                Cell cell = row.getCell(i);

                if (!cell.toString().isEmpty()) {
                    cell = row.createCell(i);
                    cell.setCellStyle(style);

                    System.out.println("not empty");


                } else {
                    System.out.println("empty");
                }
            }

            inputStream.close();

            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
