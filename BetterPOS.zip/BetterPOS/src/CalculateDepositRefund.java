
import java.util.HashMap;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class CalculateDepositRefund {
    private double totalPrice;
    
    public void depositCalc(String getType,String getItem, double quantity){
                        switch (getType.toLowerCase()){
                    case "fc"->{
                        switch (getItem) {
                            case "RS/PEPSI", "RS/RC", "RS/LEMON", "RS/COBRA", "RS/8Oz" -> totalPrice = quantity * 90;
                            case "Litro" -> totalPrice = quantity * 124;
                            case "Jumbo", "RH5" -> totalPrice = quantity * 111;
                            case "SML" -> totalPrice = quantity * 120;
                            case "Mega", "Kasalo/J5" -> totalPrice = quantity * 100;
                            case "Magnolia" -> totalPrice = quantity * 78;
                        }
                        }
                        
                    case "shell"->{
                        switch (getItem) {
                            case "RS/PEPSI", "RS/RC", "RS/LEMON", "RS/COBRA", "Magnolia", "RS/8Oz" -> totalPrice = quantity * 42;
                            case "Litro", "Mega", "Kasalo/J5" -> totalPrice = quantity * 52;
                            case "Jumbo", "RH5", "SML" -> totalPrice = quantity * 84;
                        }
                    }
                        
                    case "bot"->{
                        switch (getItem) {
                            case "RS/PEPSI", "RS/RC", "RS/LEMON", "RS/COBRA", "RS/8Oz" -> totalPrice = quantity * 2;
                            case "Litro" -> totalPrice = quantity * 6;
                            case "Jumbo" -> totalPrice = quantity * 4.5;
                            case "SML", "Magnolia" -> totalPrice = quantity * 1.5;
                            case "RH5" -> totalPrice = quantity * 2.25;
                            case "Mega", "Kasalo/J5" -> totalPrice = quantity * 4;
                        }
                    }
                        //ref starts here
                        case "ref fc" -> {
                        switch (getItem) {
                            case "RS/PEPSI", "RS/RC", "RS/LEMON", "RS/COBRA", "RS/8Oz" -> totalPrice = quantity * -90;
                            case "Litro", "Kasalo/J5" -> totalPrice = quantity * -124;
                            case "Mega" -> totalPrice = quantity * -100;
                            case "Jumbo", "RH5" -> totalPrice = quantity * -111;
                            case "SML" -> totalPrice = quantity * -120;
                            case "Magnolia" -> totalPrice = quantity * -78;

                        }
                    }
                    case "ref shell" -> {
                        switch (getItem) {
                            case "RS/PEPSI", "RS/RC", "RS/LEMON", "RS/COBRA", "Magnolia", "RS/8Oz" -> totalPrice = quantity * -42;
                            case "Litro", "Mega", "Kasalo/J5" -> totalPrice = quantity * -52;
                            case "Jumbo", "RH5", "SML" -> totalPrice = quantity * -84;
                        }
                    }
                    case "ref bot" -> {
                        
                        switch (getItem) {
                            case "RS/PEPSI", "RS/RC", "RS/LEMON", "RS/COBRA", "RS/8Oz" -> totalPrice = quantity * -2;
                            case "Litro" -> totalPrice = quantity * -6;
                            case "Jumbo" -> totalPrice = quantity * -4.5;
                            case "SML", "Magnolia" -> totalPrice = quantity * -1.5;
                            case "RH5" -> totalPrice = quantity * -2.25;
                            case "Mega", "Kasalo/J5" -> totalPrice = quantity * -4;

                        }
                    }
                        
                    default->{
                        System.out.println("none");
                        
                    }
                }
    }
    public double getTotalPrice(){
        return totalPrice;
    }
}
