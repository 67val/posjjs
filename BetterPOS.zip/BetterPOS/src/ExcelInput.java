
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
//import static org.openxmlformats.schemas.spreadsheetml.x2006.main.STPhoneticType.Enum.table;
//import static org.openxmlformats.schemas.spreadsheetml.x2006.main.STPhoneticType.Enum.table;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class ExcelInput {
    public void inputToExcel(int rowSelected, String customerName, String deliveryPickupType, HashMap<String, Double> items){
        SetSelectedFile sf = new SetSelectedFile();
        String excelFilePath = sf.getFilePath();
        for (String i : items.keySet()) {
            System.out.println("Index: " + i);
            
                System.out.println("Element found index is :" + i);
                try {
                    

                    FileInputStream inputStream = new FileInputStream(excelFilePath);
                    Workbook workbook = WorkbookFactory.create(inputStream);

                    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

                    Sheet sheet = workbook.getSheetAt(0);


                    //A switch case will be added for all ComboBoxes

                    CellStyle style = workbook.createCellStyle();
                    style.setBorderBottom(BorderStyle.THIN);
                    style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                    style.setBorderRight(BorderStyle.THIN);
                    style.setRightBorderColor(IndexedColors.BLACK.getIndex());
                    style.setBorderTop(BorderStyle.THIN);
                    style.setTopBorderColor(IndexedColors.BLACK.getIndex());
                    style.setBorderLeft(BorderStyle.THIN);
                    style.setTopBorderColor(IndexedColors.BLACK.getIndex());

                    Row r1 = sheet.getRow(rowSelected);
                        Cell c1 = r1.createCell(1);
                        c1.setCellStyle(style);
                        c1.setCellValue(customerName+ " "+ rowSelected);
                    

                    Row r5 = sheet.getRow(rowSelected);
                    Cell c5 = r5.createCell(3);
                    c5.setCellStyle(style);
                    c5.setCellValue(deliveryPickupType);


                    switch (i.toLowerCase()) {
                        case "8oz" -> {
                            Row r2 = sheet.getRow(rowSelected);
                            Cell c2 = r2.createCell(6);

                            c2.setCellStyle(style);
                            c2.setCellValue(items.get(i));

                        }
                        case "cobra y/g" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.getCell(5);
                            if (c3 != null) {

                                c3.setCellStyle(style);
                                c3.setCellFormula(c3 + "+" + items.get(i));
                            } else {
                                Cell c8 = r3.createCell(5);
                                c8.setCellStyle(style);
                                c8.setCellFormula("+" + items.get(i));
                            }
                            Cell evaluateCell = r3.getCell(5);
                            evaluator.evaluateInCell(evaluateCell);
                        }

                        case "12oz" -> {
                            Row r3 = sheet.getRow(rowSelected); //essentially 8oz for now
                            Cell c3 = r3.createCell(8);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));
                        }
                        case "sparkle" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(10);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));
                        }
                        case "rc" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(11);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));
                        }
                        case "lemon", "soda" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.getCell(12);
                            if (c3 != null) {
                                System.out.println("LEMON EMPTY 1022334");
                                c3.setCellStyle(style);
                                c3.setCellFormula(c3 + "+" + items.get(i));
                            } else {
                                System.out.println("LEMON NOT EMPTY 10000");
                                Cell c8 = r3.createCell(12);
                                c8.setCellStyle(style);
                                c8.setCellFormula("+" + items.get(i));
                            }
                            Cell evaluateCell = r3.getCell(12);
                            evaluator.evaluateInCell(evaluateCell);
                        }
                        case "mdw - 12oz" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(13);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "gatorade" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(14);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "pepsi" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(15);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "mdw-8oz" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(16);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "magnolia" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(17);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "mismo" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(18);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "swakto" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(19);
                            c3.setCellValue(items.get(i));

                        }
                        case "minute-maid" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(20);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "c2" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(21);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "v-shake" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(22);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "vita" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(23);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "pepsi litro" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(24);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "litro" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(25);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "7up/mdw litro" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(26);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "j5" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(27);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "kasalo" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(28);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "t-ice" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(30);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "j2","r2", "soda fam" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.getCell(29);
                            if (c3 != null) {
                                System.out.println("LEMON EMPTY 1022334");
                                c3.setCellStyle(style);
                                c3.setCellFormula(c3 + "+" + items.get(i));
                            } else {
                                System.out.println("LEMON NOT EMPTY 10000");
                                Cell c8 = r3.createCell(29);
                                c8.setCellStyle(style);
                                c8.setCellFormula("+" + items.get(i));
                            }
                            Cell evaluateCell = r3.getCell(29);
                            evaluator.evaluateInCell(evaluateCell);

                        }
                        case "jumbo" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(32);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "grande" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(33);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "rh-500" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(34);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "stallion" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(35);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "pilsen" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(36);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "sml" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(37);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "flavored" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(38);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "jamaica" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(39);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "t65 - flat" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(40);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "5yrs flat" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(41);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "t65 long" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(42);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "5-yrs long" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(43);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "1.5l" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(44);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "1.25l" ->{
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(45);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));
                        }
                        case "astig" ->{
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(46);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));
                        }
                        case "qute" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(47);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "w-330" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(48);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "w-500" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(49);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "ab-6000" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(50);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "w-7000" -> {
                            Row r3 = sheet.getRow(rowSelected);
                            Cell c3 = r3.createCell(51);
                            c3.setCellStyle(style);
                            c3.setCellValue(items.get(i));

                        }
                        case "cobra r" -> {
                            Row r3 = sheet.getRow(rowSelected);


                            Cell c3 = r3.getCell(5);
                            Cell c6 = r3.getCell(63);
                            if (c3 == null) {
                                Cell c4 = r3.createCell(5);
                                c4.setCellStyle(style);
                                c4.setCellFormula("+" + items.get(i));

                            } else {
                                c3.setCellStyle(style);
                                c3.setCellFormula(c3 + "+" + items.get(i));
                            }

                            if (c6 == null) {

                                Cell c7 = r3.createCell(63);
                                c7.setCellStyle(style);
                                c7.setCellFormula("-" + items.get(i) * 26);

                                System.out.println("DISCOUNT COBRA R (100104)");
                            } else {
                                c6.setCellStyle(style);
                                c6.setCellFormula("-" + items.get(i) * 26);
                            }
                            Cell evaluateCell = r3.getCell(12);
                            evaluator.evaluateInCell(evaluateCell);

                        }
                        default -> {
                            
                        }
                    }


                    inputStream.close();

                    FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                    workbook.write(outputStream);
                    workbook.close();
                    outputStream.close();

                    System.out.println("Successfully Written!");
                    System.out.println("Typed at " + rowSelected);


                } catch (IOException | EncryptedDocumentException ex) {
                    ex.printStackTrace();
                }

        }
    }
}
