
import java.awt.Color;
import java.awt.Font;
import java.awt.TextField;
import java.awt.print.PrinterException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;
import java.util.TimerTask;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.standard.MediaPrintableArea;
import javax.swing.JOptionPane;
import java.util.Timer;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class POSFrame extends javax.swing.JFrame {

    /**
     * Creates new form POSFrame
     */
    GetCustomerPurchases ps = new GetCustomerPurchases();
    HashMap<String, Integer> customerPurchases = new HashMap<>(); // CusName, Row in excel
    HashMap<String, Double> items = new HashMap<>(); // Item Name, Quantity for excel file
    
    
     DecimalFormat dfComma = new DecimalFormat("#,###.00");
    // clear this part once paper is printed/print is clicked
    HashMap<String, Double> newPurchases = new HashMap<>(); // Item Name, Quantity for new customer
    
    HashMap<String, Double> discountQuantity = new HashMap<>();
    HashMap<String, Double> discountPricePerItem = new HashMap<>();
    
    HashMap<String, Double> depositItem = new HashMap<>(); // Which item is being deposited + quantity
    HashMap<String, String> depositType = new HashMap<>(); //Deposit type: full case, shell etc. also includes refunds
    
    HashMap<String, Double> sariSariQuantityMap = new HashMap<>();
    HashMap<String, Double> sariSariUnitPriceMap = new HashMap<>();
    
    
    private SetSelectedFile stf = new SetSelectedFile();
    
    public POSFrame() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("JJS Sam Store POS SYSTEM");
        
        selectedFile.setText(stf.getFilePath()); // sets the selected file
        
        loadCustomerNames();
        
        itemBox.setLightWeightPopupEnabled(true);
        AutoCompleteDecorator.decorate(itemBox);
        
        customerPurchaseListTable.setFocusable(false);
        customerPurchaseListTable.setRowSelectionAllowed(false);
    }
    public void inputToExcel(){
        SetRowSelected ss = new SetRowSelected();
        ss.rowSelect("min", Objects.requireNonNull(deliveryPickupComboBox.getSelectedItem().toString()));
        EmptyRowFinder mp = new EmptyRowFinder(ss.getIndex());
        
        String customerName = receiptName.getText();
        int rowSelected = mp.getEmptyRow();
        String deliveryPickupType = Objects.requireNonNull(deliveryPickupComboBox.getSelectedItem().toString());
        
        ExcelInput ex = new ExcelInput();
        ex.inputToExcel(rowSelected, customerName, deliveryPickupType, newPurchases);// Excel Input for regular items
        
        SariSariExcelInput sr = new SariSariExcelInput();
        sr.excelInputSariSari(sariSariQuantityMap, sariSariUnitPriceMap, rowSelected);
        
        DepositExcelInput dp = new DepositExcelInput();
        dp.depositInput(depositItem, depositType, rowSelected, customerName, deliveryPickupType);
        
        DiscountExcelInput dsc = new DiscountExcelInput();
        dsc.discountInput(discountQuantity, discountPricePerItem, rowSelected);
    }
    
    public void addPlaceHolder(TextField textField){
        Font font = textField.getFont();
        font = font.deriveFont(Font.ITALIC);
        
        textField.setFont(font);
        textField.setForeground(Color.gray);
    }
    public void removePlaceHolder(TextField textField){
        Font font = textField.getFont();
        font = font.deriveFont(Font.PLAIN | Font.BOLD);
        
        textField.setFont(font);
        textField.setForeground(Color.black);
    }
    
    public void loadCustomerNames(){ //This code iterates through the excel files one by one and stores the text and rowFound in a hashmap
        SetSelectedFile st = new SetSelectedFile();
        String excelFilePath = st.getFilePath();
        SetRowSelected rs = new SetRowSelected();
        try {

            FileInputStream inputStream = new FileInputStream(excelFilePath);
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            rs.rowSelect("min", Objects.requireNonNull(deliveryPickupComboBox.getSelectedItem().toString()));
            rs.rowSelect("max", Objects.requireNonNull(deliveryPickupComboBox.getSelectedItem().toString()));
            int indf = rs.getIndex(); //Index first
            int index = rs.getIndexMax();
            System.out.println(indf);

            for(int f = indf; f<index; f++){
                Row readRow = sheet.getRow(f);
                Cell cell100 = readRow.getCell(1);
                if (cell100.toString().isEmpty()) {
                    System.out.println("");
                } else {
                    DefaultTableModel model = (DefaultTableModel) customerTable.getModel();
                    String[] tb = {cell100.toString()};
                    model.addRow(tb);
                    addToHashMap(cell100.toString(),f);
                    
                }
            }
            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();

            //System.out.println("CODEx100100: ROW SELECTED = 2");


        } catch (IOException | EncryptedDocumentException ex) {
            ex.printStackTrace();
        }
    }
    
    public void addToHashMap(String cusName, int rowNumber){
        customerPurchases.put(cusName, rowNumber);
    }
    public int getCusRow(String cusName){
        return customerPurchases.get(cusName);
    }
    
    public void getTotalCashAmount(){ //Will take the sum of the rightmost column and use it to calculate the total amount
        double modelTotal = 0;
        double depModelTotal = 0;
        double discModelTotal = 0;
        
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        DefaultTableModel depModel = (DefaultTableModel) depositTable.getModel();
        DefaultTableModel discModel = (DefaultTableModel) discountTable.getModel();
        
        for(int i = 0; i<model.getRowCount(); i++){
            modelTotal = modelTotal+ Double.parseDouble(model.getValueAt(i, 2).toString());
        }
        for(int i = 0; i<depModel.getRowCount(); i++){
            depModelTotal = depModelTotal+ Double.parseDouble(depModel.getValueAt(i, 3).toString());
        }
        for(int i = 0; i<discModel.getRowCount(); i++){
            discModelTotal = discModelTotal+ Double.parseDouble(discModel.getValueAt(i, 3).toString());
        }
        
        CalculateInvoice cs = new CalculateInvoice(modelTotal, discModelTotal, depModelTotal);
        totalInvoice.setText(String.valueOf(cs.getTotalAmt()));
    }
    
    public void createReceipt(int rowSelected){
        printTextPane.setText("\n");

        printTextPane.setText(printTextPane.getText() + "Date:" + java.time.LocalDate.now() + "\n");
        printTextPane.setText(printTextPane.getText() + "Order ID: " + (rowSelected) + "\n");
       

        switch (Objects.requireNonNull(deliveryPickupComboBox.getSelectedItem()).toString().toLowerCase(Locale.ROOT)) {
            case "pickup" -> printTextPane.setText(printTextPane.getText() + "Type: Pick-up" + "\n");
            case "nicanor" -> printTextPane.setText(printTextPane.getText() + "Delivered By: Nicanor" + "\n");
            case "willy" -> printTextPane.setText(printTextPane.getText() + "Delivered By: Willy" + "\n");
            case "chito" -> printTextPane.setText(printTextPane.getText() + "Delivered By: Chito" + "\n");
        }

        printTextPane.setText(printTextPane.getText() + "Cus: " + receiptName.getText() + "\n");
        printTextPane.setText(printTextPane.getText() + "========================" + "\n");
        printTextPane.setText(printTextPane.getText() + "Qty   Item                  Unit       Sum" + "\n");

        CalculatePrice cs = new CalculatePrice();
        for (String i : newPurchases.keySet()) {
            double unitPrice;
            String itemName = i;
            double quantity = newPurchases.get(i);
            double totalPrice = cs.calculatePrice(quantity, i);
            
            unitPrice = cs.calculatePrice(quantity, i)/quantity;
            
            printTextPane.setText(printTextPane.getText() + " " + quantity + "     " + itemName + "\t" + dfComma.format(unitPrice) + "    " + dfComma.format(totalPrice) + "\n");
        }
        
        for (String i : sariSariQuantityMap.keySet()) {
            double unitPrice;
            String itemName = i;
            double quantity = sariSariQuantityMap.get(i);
            double totalPrice = cs.calculatePrice(quantity, i);
            
            unitPrice = cs.calculatePrice(quantity, i)/quantity;
            
            printTextPane.setText(printTextPane.getText() + " " + quantity + "     " + itemName + "\t" + dfComma.format(unitPrice) + "    " + dfComma.format(totalPrice) + "\n");
        }

        System.out.println("Created Receipt!");
    }
    
    public void closeReceipt() {
        //clean up close receipt later.
        double quant = 0;
        for (String i : newPurchases.keySet()) {
            quant = quant+newPurchases.get(i);
        }
        
        
        
        GetItemsTotalAmount sf = new GetItemsTotalAmount(newPurchases);
        
        
        String subTotal = "Sub Total: " + String.valueOf(sf.getTotalAmount());


        printTextPane.setText("\n" + printTextPane.getText() + "------------------------------------------------" + "\n");
        printTextPane.setText("\n" + printTextPane.getText() + "Total Qty: " + quant + "\n");

        double totalDiscount = 0;
        
        for(String i : discountQuantity.keySet()){
            CalculateDiscountPrice dc = new CalculateDiscountPrice(discountQuantity.get(i), discountPricePerItem.get(i));
            totalDiscount = totalDiscount + dc.getTotalDiscount();
        }
        
        
        printTextPane.setText(printTextPane.getText() + "                       " + subTotal + "\n");
        printTextPane.setText(printTextPane.getText() + "                       " + "Discount: " + dfComma.format(totalDiscount) + "\n");

        printTextPane.setText(printTextPane.getText() + "------------------------------------------------------" + "\n");
        printTextPane.setText(printTextPane.getText() + "                       Deposit" + "\n");
        printTextPane.setText(printTextPane.getText() + "------------------------------------------------------" + "\n");
        
        DefaultTableModel tableModel2 = (DefaultTableModel) depositTable.getModel();
        
        for (int i = 0; i < tableModel2.getRowCount(); i++) {
            double unitPrice = Double.parseDouble(String.valueOf(tableModel2.getValueAt(i, 3))) / Double.parseDouble(String.valueOf(tableModel2.getValueAt(i, 2)));


            String col1 =  String.valueOf(tableModel2.getValueAt(i, 2));
            String col2 = String.valueOf(tableModel2.getValueAt(i, 0));
            String col3 = String.valueOf(tableModel2.getValueAt(i, 1));
            String col4 = String.valueOf(tableModel2.getValueAt(i, 3));

            printTextPane.setText(printTextPane.getText() + "   " + col1 + "    " + col2 + "  " + col3 + "\t" + "  " + dfComma.format(unitPrice) + "              " + col4 + "\n");
        }


        double total = Double.parseDouble(totalInvoice.getText());
       

        //printTextPane.setText(printTextPane.getText()+"   Discount:    "+"\n");
        printTextPane.setText(printTextPane.getText() + "------------------------------------------------------" + "\n");
        Font font = new Font("Tahoma", Font.PLAIN, 20);
        printTextPane.setFont(font);
        printTextPane.setText(printTextPane.getText() + "                    Total: " + dfComma.format(total) + "\n");
        Font font2 = new Font("Tahoma", Font.PLAIN, 8);
        printTextPane.setFont(font2);
        printTextPane.setText(printTextPane.getText() + "===========================" + "\n");
        printTextPane.setText(printTextPane.getText() + "                    THANK YOU " + "\n");
        printTextPane.setText(printTextPane.getText() + "===========================" + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + " " + "\n");
        printTextPane.setText(printTextPane.getText() + ". " + "\n");

    }
    
    public void printReceipt() {

        posTab.setSelectedIndex(2);
        HashPrintRequestAttributeSet attr = new HashPrintRequestAttributeSet();
        attr.add(new MediaPrintableArea(0, 0, 48, 210, MediaPrintableArea.MM));
        //attr.add(new MediaPrintableArea(0, 0, 48, 210, MediaPrintableArea.MM));


        MessageFormat headerFormat = new MessageFormat("Order Slip");

        //MessageFormat footer = new MessageFormat("Total: " + dfComma.format(totalCopy));


        try {
            printTextPane.print(headerFormat, null, true, null, attr, true);
        } catch (PrinterException e) {
            e.printStackTrace();
        }
        posTab.setSelectedIndex(0);
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textField3 = new java.awt.TextField();
        posTab = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        purchaseListTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        depositTable = new javax.swing.JTable();
        itemBox = new javax.swing.JComboBox<>();
        addItemButton = new javax.swing.JButton();
        depositComboBox = new javax.swing.JComboBox<>();
        addDepositButton = new javax.swing.JButton();
        itemQuantityField = new java.awt.TextField();
        depositQuantityField = new java.awt.TextField();
        jPanel3 = new javax.swing.JPanel();
        changeTabButton = new javax.swing.JButton();
        receiptName = new javax.swing.JTextField();
        cashButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();
        closeTransactionBtn = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        discountTable = new javax.swing.JTable();
        caseShellBot = new javax.swing.JComboBox<>();
        discountPricePer = new java.awt.TextField();
        discountQuantityField = new java.awt.TextField();
        discountComboBox = new javax.swing.JComboBox<>();
        addDiscountBtn = new javax.swing.JButton();
        totalInvoice = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        deleteButton = new javax.swing.JButton();
        sariSariQuantity = new java.awt.TextField();
        sariSariUnitPrice = new java.awt.TextField();
        sariSariItemName = new java.awt.TextField();
        addSariSariBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        changeTabButtonTab1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        customerTable = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        customerPurchaseListTable = new javax.swing.JTable();
        selectedFile = new java.awt.TextField();
        totalField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        shellField = new java.awt.TextField();
        botField = new java.awt.TextField();
        fcField = new java.awt.TextField();
        formulaField = new java.awt.TextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        deleteCusData = new javax.swing.JButton();
        editPurchasesBtn = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 32767));
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 32767));
        jLabel7 = new javax.swing.JLabel();
        filler3 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 32767));
        jPanel4 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        printTextPane = new javax.swing.JTextPane();
        deliveryPickupComboBox = new javax.swing.JComboBox<>();

        textField3.setText("textField1");
        textField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField3ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        posTab.setBackground(new java.awt.Color(255, 255, 255));
        posTab.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        purchaseListTable.setBackground(new java.awt.Color(255, 255, 255));
        purchaseListTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Quantity", "Total Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(purchaseListTable);
        if (purchaseListTable.getColumnModel().getColumnCount() > 0) {
            purchaseListTable.getColumnModel().getColumn(0).setResizable(false);
            purchaseListTable.getColumnModel().getColumn(1).setResizable(false);
            purchaseListTable.getColumnModel().getColumn(2).setResizable(false);
        }

        depositTable.setBackground(new java.awt.Color(255, 255, 255));
        depositTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Deposit", "Type", "Qty", "Total Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(depositTable);
        if (depositTable.getColumnModel().getColumnCount() > 0) {
            depositTable.getColumnModel().getColumn(0).setResizable(false);
            depositTable.getColumnModel().getColumn(1).setResizable(false);
            depositTable.getColumnModel().getColumn(2).setResizable(false);
            depositTable.getColumnModel().getColumn(3).setResizable(false);
        }

        itemBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None Selected", "Cobra Y/G", "Cobra R", "8Oz", "12Oz", "Sparkle", "Rc", "Lemon", "Soda", "Soda Fam", "MDW - 12Oz", "Gatorade", "Pepsi", "MDW-8Oz", "Magnolia", "Mismo", "Swakto", "Minute-Maid", "C2", "Vita", "Pepsi Litro", "Litro", "7UP/MDW LITRO", "J5", "Kasalo", "R2", "T-ICE", "J2", "Jumbo", "Grande", "RH-500", "Stallion", "Pilsen", "SML", "Flavored", "Jamaica", "T65 - Flat", "5YRS Flat", "T65 Long", "5-YRS Long", "1.5L", "1.25L", "Astig", "QUTE", "W-330", "W-500", "AB-6000", "W-7000" }));
        itemBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                itemBoxItemStateChanged(evt);
            }
        });
        itemBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBoxActionPerformed(evt);
            }
        });
        itemBox.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                itemBoxKeyPressed(evt);
            }
        });

        addItemButton.setText("Add Item");
        addItemButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addItemButtonActionPerformed(evt);
            }
        });

        depositComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Litro", "Jumbo", "SML", "RH5", "Mega", "Magnolia", "Kasalo/J5", "RS/RC", "RS/LEMON", "RS/PEPSI", "RS/COBRA", "RS/8OZ", " " }));
        depositComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                depositComboBoxItemStateChanged(evt);
            }
        });

        addDepositButton.setText("Add Deposit");
        addDepositButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDepositButtonActionPerformed(evt);
            }
        });

        itemQuantityField.setFont(new java.awt.Font("Dialog", 2, 12)); // NOI18N
        itemQuantityField.setForeground(new java.awt.Color(153, 153, 153));
        itemQuantityField.setText("Quantity");
        itemQuantityField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                itemQuantityFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                itemQuantityFieldFocusLost(evt);
            }
        });
        itemQuantityField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemQuantityFieldActionPerformed(evt);
            }
        });
        itemQuantityField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                itemQuantityFieldKeyPressed(evt);
            }
        });

        depositQuantityField.setFont(new java.awt.Font("Dialog", 2, 12)); // NOI18N
        depositQuantityField.setForeground(new java.awt.Color(153, 153, 153));
        depositQuantityField.setText("Quantity");
        depositQuantityField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                depositQuantityFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                depositQuantityFieldFocusLost(evt);
            }
        });
        depositQuantityField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                depositQuantityFieldKeyPressed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        changeTabButton.setText(">");
        changeTabButton.setAutoscrolls(true);
        changeTabButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeTabButtonActionPerformed(evt);
            }
        });

        receiptName.setBackground(new java.awt.Color(255, 255, 255));
        receiptName.setForeground(new java.awt.Color(0, 0, 0));

        cashButton.setBackground(new java.awt.Color(255, 255, 255));
        cashButton.setForeground(new java.awt.Color(0, 0, 0));
        cashButton.setText("Cash");
        cashButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cashButtonActionPerformed(evt);
            }
        });

        printButton.setText("Print Button");
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });

        closeTransactionBtn.setText("Close Transaction");
        closeTransactionBtn.setEnabled(false);
        closeTransactionBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeTransactionBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(receiptName)
                    .addComponent(cashButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(printButton, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(changeTabButton, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(closeTransactionBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(receiptName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cashButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(printButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(closeTransactionBtn)
                .addGap(219, 219, 219)
                .addComponent(changeTabButton)
                .addContainerGap())
        );

        discountTable.setBackground(new java.awt.Color(255, 255, 255));
        discountTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Discount Quantity", "Discount Unit", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(discountTable);
        if (discountTable.getColumnModel().getColumnCount() > 0) {
            discountTable.getColumnModel().getColumn(0).setResizable(false);
            discountTable.getColumnModel().getColumn(1).setResizable(false);
            discountTable.getColumnModel().getColumn(2).setResizable(false);
            discountTable.getColumnModel().getColumn(3).setResizable(false);
        }

        caseShellBot.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FC", "Shell", "Bot", "Ref Bot", "Ref Shell", "Ref FC" }));
        caseShellBot.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                caseShellBotItemStateChanged(evt);
            }
        });

        discountPricePer.setFont(new java.awt.Font("Dialog", 2, 12)); // NOI18N
        discountPricePer.setForeground(new java.awt.Color(153, 153, 153));
        discountPricePer.setName(""); // NOI18N
        discountPricePer.setText("Discount Unit Price");
        discountPricePer.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                discountPricePerFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                discountPricePerFocusLost(evt);
            }
        });
        discountPricePer.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                discountPricePerKeyPressed(evt);
            }
        });

        discountQuantityField.setFont(new java.awt.Font("Dialog", 2, 12)); // NOI18N
        discountQuantityField.setForeground(new java.awt.Color(153, 153, 153));
        discountQuantityField.setText("Quantity");
        discountQuantityField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                discountQuantityFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                discountQuantityFieldFocusLost(evt);
            }
        });
        discountQuantityField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                discountQuantityFieldKeyPressed(evt);
            }
        });

        discountComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cobra", "8Oz", "Litro", "RC", "Lemon", "L-Fam", "Mega", "SML", "Jumbo", "1.5", "1.25", "Swakto", "Mismo", "Qute", "Astig", "Wil - 350ml", "Wil -  500", "Wil - 1000", "Wil - 7LTR", "AB - 350", "AB - 500", "AB - 1000", "AB - 6LTR", "Sum - 350", "Sum - 500", "Sum - 1000", "T-65L", "T-65F", "5YRS-F", "5YRS-L", "Jamaica", " ", " " }));
        discountComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                discountComboBoxActionPerformed(evt);
            }
        });

        addDiscountBtn.setText("Add Discount");
        addDiscountBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDiscountBtnActionPerformed(evt);
            }
        });

        totalInvoice.setEditable(false);

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Total Amount:");

        deleteButton.setForeground(new java.awt.Color(255, 51, 51));
        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        sariSariQuantity.setFont(new java.awt.Font("Dialog", 2, 12)); // NOI18N
        sariSariQuantity.setForeground(new java.awt.Color(153, 153, 153));
        sariSariQuantity.setText("Quantity");
        sariSariQuantity.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                sariSariQuantityFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                sariSariQuantityFocusLost(evt);
            }
        });
        sariSariQuantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                sariSariQuantityKeyPressed(evt);
            }
        });

        sariSariUnitPrice.setFont(new java.awt.Font("Dialog", 2, 12)); // NOI18N
        sariSariUnitPrice.setForeground(new java.awt.Color(153, 153, 153));
        sariSariUnitPrice.setName(""); // NOI18N
        sariSariUnitPrice.setText("Sari Sari Unit Price");
        sariSariUnitPrice.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                sariSariUnitPriceFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                sariSariUnitPriceFocusLost(evt);
            }
        });
        sariSariUnitPrice.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                sariSariUnitPriceKeyPressed(evt);
            }
        });

        sariSariItemName.setFont(new java.awt.Font("Dialog", 2, 12)); // NOI18N
        sariSariItemName.setForeground(new java.awt.Color(153, 153, 153));
        sariSariItemName.setText("Sari Sari Item Name");
        sariSariItemName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                sariSariItemNameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                sariSariItemNameFocusLost(evt);
            }
        });
        sariSariItemName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                sariSariItemNameKeyPressed(evt);
            }
        });

        addSariSariBtn.setText("Add Sari Sari");
        addSariSariBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSariSariBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 819, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(sariSariQuantity, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(itemQuantityField, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                                    .addComponent(depositQuantityField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(discountQuantityField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(sariSariUnitPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sariSariItemName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(itemBox, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(depositComboBox, 0, 227, Short.MAX_VALUE)
                                    .addComponent(discountPricePer, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(totalInvoice, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(deleteButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(caseShellBot, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(discountComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(addItemButton, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                            .addComponent(addDepositButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(addDiscountBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(addSariSariBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(itemQuantityField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(itemBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(addItemButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(depositQuantityField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(depositComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(caseShellBot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(addDepositButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(discountComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(discountPricePer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(discountQuantityField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sariSariQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sariSariUnitPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sariSariItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(addDiscountBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addSariSariBtn)))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(totalInvoice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(deleteButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(27, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        posTab.addTab("Main", jPanel1);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        changeTabButtonTab1.setText("<");
        changeTabButtonTab1.setAutoscrolls(true);
        changeTabButtonTab1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeTabButtonTab1ActionPerformed(evt);
            }
        });

        customerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customers"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        customerTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customerTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(customerTable);
        if (customerTable.getColumnModel().getColumnCount() > 0) {
            customerTable.getColumnModel().getColumn(0).setResizable(false);
        }

        customerPurchaseListTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Quantity", "Total Price", "Discount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(customerPurchaseListTable);
        if (customerPurchaseListTable.getColumnModel().getColumnCount() > 0) {
            customerPurchaseListTable.getColumnModel().getColumn(0).setResizable(false);
            customerPurchaseListTable.getColumnModel().getColumn(1).setResizable(false);
            customerPurchaseListTable.getColumnModel().getColumn(2).setResizable(false);
            customerPurchaseListTable.getColumnModel().getColumn(3).setResizable(false);
        }

        selectedFile.setEditable(false);

        totalField.setEditable(false);
        totalField.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Total Amount:");

        shellField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shellFieldActionPerformed(evt);
            }
        });

        botField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botFieldActionPerformed(evt);
            }
        });

        fcField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fcFieldActionPerformed(evt);
            }
        });

        formulaField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formulaFieldActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("Bottle");

        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Shell");

        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Full case");

        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("Formula");

        jButton1.setText("Edit Deposit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        deleteCusData.setForeground(new java.awt.Color(255, 51, 51));
        deleteCusData.setText("Delete Customer");
        deleteCusData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteCusDataActionPerformed(evt);
            }
        });

        editPurchasesBtn.setText("Edit Purchases");
        editPurchasesBtn.setEnabled(false);
        editPurchasesBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editPurchasesBtnActionPerformed(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MayNeedCode/posLogo__2_-removebg-preview.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(changeTabButtonTab1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 632, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(totalField, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(editPurchasesBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteCusData, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(fcField, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(filler3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 382, Short.MAX_VALUE)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(selectedFile, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(jLabel4)
                                                    .addComponent(jLabel6))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(formulaField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(shellField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(botField, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(filler3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(117, 117, 117))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel1)
                                                .addComponent(totalField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(editPurchasesBtn)
                                                .addComponent(jButton1))
                                            .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteCusData)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel6))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(selectedFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(botField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(shellField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                                        .addGap(12, 12, 12)
                                        .addComponent(fcField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(formulaField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(56, 56, 56)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(changeTabButtonTab1)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );

        posTab.addTab("First Panel", jPanel2);

        printTextPane.setEditable(false);
        jScrollPane7.setViewportView(printTextPane);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 855, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(156, Short.MAX_VALUE))
        );

        posTab.addTab("Receipt Preview", jPanel4);

        deliveryPickupComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pickup", "Chito", "Willy", "Nicanor", " " }));
        deliveryPickupComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                deliveryPickupComboBoxItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(posTab)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(deliveryPickupComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(deliveryPickupComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(posTab, javax.swing.GroupLayout.PREFERRED_SIZE, 575, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void changeTabButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeTabButtonActionPerformed
        // TODO add your handling code here:
        posTab.setSelectedIndex(1);
    }//GEN-LAST:event_changeTabButtonActionPerformed

    private void changeTabButtonTab1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeTabButtonTab1ActionPerformed
        // TODO add your handling code here:
        posTab.setSelectedIndex(0);
        
    }//GEN-LAST:event_changeTabButtonTab1ActionPerformed

    //This code takes the item of itemBox combobox, user input in the textfield, multiplies the quantity by price and adds values into the jtable
    private void addItemButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addItemButtonActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        model.setRowCount(0);
        newPurchases();
        if(sariSariQuantityMap.size()!= 0){
            loadSariSariMethod();
        }
       
    }//GEN-LAST:event_addItemButtonActionPerformed
    
    public void newPurchases(){
        try{
        CalculatePrice calc = new CalculatePrice();
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        model.setRowCount(0);
        String itemName = Objects.requireNonNull(itemBox.getSelectedItem().toString());
        double itemQuantity = Double.parseDouble(itemQuantityField.getText());
        
        if(itemName.equals("None Selected")){
            JOptionPane.showMessageDialog(null, "Choose an Item!");
            loadNewPurchases();
        }
        else{
            if(newPurchases.containsKey(itemName)){
                newPurchases.put(itemName, newPurchases.get(itemName)+itemQuantity);
            }
            else{
                newPurchases.put(itemName, itemQuantity);
            }
            loadNewPurchases(); // loads the purchases onto the table
            getTotalCashAmount();
        }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Type an appropriate number", "Error", JOptionPane.WARNING_MESSAGE);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    public void loadNewPurchases(){
        CalculatePrice calc = new CalculatePrice();
         DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        double totAmt = 0;
        for(String i : newPurchases.keySet()){
            double totalPrice = calc.calculatePrice(newPurchases.get(i), i);
            
            totAmt = totAmt + totalPrice;
            Object[] row = {i, newPurchases.get(i), totalPrice};
            model.addRow(row);
            totalInvoice.setText(String.valueOf(totAmt));
        }
    }
    
    private void itemBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBoxActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_itemBoxActionPerformed
    public void displayDeposit(String cusName){
        GetCustomerDeposits ds = new GetCustomerDeposits();
        ds.getCusDeposit(customerPurchases.get(cusName));
        
        botField.setText(ds.getBotValue());
        shellField.setText(ds.getShellValue());
        fcField.setText(ds.getFcValue());
        formulaField.setText(ds.getFormulaValue());
        
        //TODO: PROBLEM HERE FIX IT.. ALONG WITH GETCUSTOMERDEPOSITS
    }
    private void customerTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customerTableMouseClicked
        // TODO add your handling code here:
        
         if (evt.getButton() == java.awt.event.MouseEvent.BUTTON1) {
                GetCustomerPurchases ps = new GetCustomerPurchases();
            CalculatePrice calc = new CalculatePrice();
        
            int row = customerTable.getSelectedRow();
            String customer = customerTable.getModel().getValueAt(row, 0).toString();
            ps.setItems(customerPurchases.get(customer));
            items.clear();
            items = ps.getItemsList();
        
        
            DefaultTableModel cusModel = (DefaultTableModel) customerPurchaseListTable.getModel();
            cusModel.setRowCount(0);
        
            double totalAmt = 0.0;
            for(String i : items.keySet()){
                double total = calc.calculatePrice(items.get(i), i);
                totalAmt = totalAmt + total;
                Object[] tb = {i, items.get(i), total};
                cusModel.addRow(tb);
            }
            Object[] tb1 = {null, null, null, discountColumn(customerPurchases.get(customer))};
            cusModel.addRow(tb1);
            totalField.setText(String.valueOf(totalAmt));
            displayDeposit(customer);
            }
         
         if(evt.getButton() == java.awt.event.MouseEvent.BUTTON2){ //Undo post to excel and reload the purchases into form.
             DefaultTableModel cusModel = (DefaultTableModel) customerTable.getModel();
             DefaultTableModel cusPurList = (DefaultTableModel) customerPurchaseListTable.getModel();
             String cusName = cusModel.getValueAt(customerTable.getSelectedRow(), 0).toString();
             newPurchases = items;
             loadNewPurchases();
             posTab.setSelectedIndex(0);
             deleteExcelRow();
             cusPurList.setRowCount(0);
             
         }
        
        
    }//GEN-LAST:event_customerTableMouseClicked
    public String discountColumn(int rowSel){
        SetSelectedFile sf = new SetSelectedFile();
        String excelFilePath = sf.getFilePath();
        
        String cellDisc = "";
        try{
            FileInputStream inputStream = new FileInputStream(excelFilePath);
            Workbook workbook = WorkbookFactory.create(inputStream);

            Sheet sheet = workbook.getSheetAt(0);
            
            Row row = sheet.getRow(rowSel);
            Cell cell = row.getCell(63);
            inputStream.close();
            cellDisc = cell.toString();

            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
            
        }
        catch(IOException | EncryptedDocumentException ex){
            ex.printStackTrace();
        }
        return cellDisc;
    }
    private void deliveryPickupComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_deliveryPickupComboBoxItemStateChanged
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) customerTable.getModel();
        DefaultTableModel purchaseListModel = (DefaultTableModel) customerPurchaseListTable.getModel();
        model.setRowCount(0);
        purchaseListModel.setRowCount(0);
        loadCustomerNames();
    }//GEN-LAST:event_deliveryPickupComboBoxItemStateChanged

    private void addDepositButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDepositButtonActionPerformed
        // TODO add your handling code here:
        addDepositMethod();        
    }//GEN-LAST:event_addDepositButtonActionPerformed
    
    public void addDepositMethod(){
        try{
         CalculateDepositRefund cdr = new CalculateDepositRefund();
        String itemDeposited = Objects.requireNonNull(depositComboBox.getSelectedItem().toString());
        String itemTypeDeposited = Objects.requireNonNull(caseShellBot.getSelectedItem().toString());
        double quantity = Double.parseDouble(depositQuantityField.getText());
        String item = itemDeposited + " " + itemTypeDeposited;
        
        if(depositType.containsKey(item) && depositType.get(item).equals(itemTypeDeposited)){
            depositItem.put(item, depositItem.get(item) + quantity);
        }
        else{
            depositType.put(item, itemTypeDeposited);
            depositItem.put(item, quantity);
        }
        
        DefaultTableModel depModel = (DefaultTableModel) depositTable.getModel();
        depModel.setRowCount(0);
        for(String i : depositItem.keySet()){
            String[] split = i.split(" ");
            cdr.depositCalc(depositType.get(i), split[0], depositItem.get(i));
            double totPrice = cdr.getTotalPrice();
            Object[] tb = {i, depositType.get(i), depositItem.get(i), totPrice};
            depModel.addRow(tb);
        }
        getTotalCashAmount();
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Type an appropriate number", "Error", JOptionPane.WARNING_MESSAGE);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong...", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void cashButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cashButtonActionPerformed
        // TODO add your handling code here:
        receiptName.setText("Cash");
    }//GEN-LAST:event_cashButtonActionPerformed

    private void addDiscountBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDiscountBtnActionPerformed
        // TODO add your handling code here:
        addDiscountMethod();
        
    }//GEN-LAST:event_addDiscountBtnActionPerformed
    public void addDiscountMethod(){
        try{
        double quantity = Double.parseDouble(discountQuantityField.getText());
        double pricePer = Double.parseDouble(discountPricePer.getText());
        String keyItem = Objects.requireNonNull(discountComboBox.getSelectedItem().toString());
        DefaultTableModel discModel = (DefaultTableModel) discountTable.getModel();
        
        //discountQuantity.put(keyItem, quantity);
        //discountPricePerItem.put(keyItem, pricePer);
        
        if(discountQuantity.containsKey(keyItem)){
            discountQuantity.put(keyItem, discountQuantity.get(keyItem) + quantity);
        }
        else{
            discountPricePerItem.put(keyItem, pricePer);
            discountQuantity.put(keyItem, quantity);
        }
        
        discModel.setRowCount(0);
        
        for(String i : discountQuantity.keySet()){
            CalculateDiscountPrice cs = new CalculateDiscountPrice(discountQuantity.get(i), discountPricePerItem.get(i));
            double totDisc = cs.getTotalDiscount();
            Object[] tb = {i, discountQuantity.get(i),discountPricePerItem.get(i), totDisc};
            discModel.addRow(tb);
        }
        getTotalCashAmount();
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Type an appropriate number", "Error", JOptionPane.WARNING_MESSAGE);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong...", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        
        try{
            int tableRowSelected = purchaseListTable.getSelectedRow();
        int depTableRowSelected = depositTable.getSelectedRow();
        int discTableRowSelected = discountTable.getSelectedRow();
        
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        DefaultTableModel depModel = (DefaultTableModel) depositTable.getModel();
        DefaultTableModel discModel = (DefaultTableModel) discountTable.getModel();
        
        if(tableRowSelected>=0){
            String sariSari = model.getValueAt(purchaseListTable.getSelectedRow(), 0).toString().substring(0, 3);
            String selectedItem = model.getValueAt(purchaseListTable.getSelectedRow(), 0).toString();
            if (sariSari.equals("Sri")){
                
                sariSariUnitPriceMap.remove(selectedItem);
                sariSariQuantityMap.remove(selectedItem); // removes for sari sari items
                model.removeRow(tableRowSelected);
                System.out.println("sarisari removed successfully.");
                System.out.println(sariSariUnitPriceMap);
            }
            
            else{
                newPurchases.remove(model.getValueAt(tableRowSelected, 0).toString()); //Removes the selected item from the hashmap and table
                model.removeRow(tableRowSelected);
            }
            
        }
        
         if(depTableRowSelected>=0){
            depositItem.remove(depModel.getValueAt(depTableRowSelected, 0).toString()); 
            depositType.remove(depModel.getValueAt(depTableRowSelected, 0).toString()); //Removes the selected item from the hashmap and table for deposit
            depModel.removeRow(depTableRowSelected);
        }
         
         if(discTableRowSelected>=0){
            discountQuantity.remove(discModel.getValueAt(discTableRowSelected, 0).toString()); 
            discountPricePerItem.remove(discModel.getValueAt(discTableRowSelected, 0).toString()); //Removes the selected item from the hashmap and table for discount
            discModel.removeRow(discTableRowSelected);
        }
        getTotalCashAmount();
        
        depositTable.clearSelection();
        purchaseListTable.clearSelection();
        discountTable.clearSelection();
        }
        catch(ArrayIndexOutOfBoundsException e){
            JOptionPane.showMessageDialog(null, "All deleted");
        }
        
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void itemQuantityFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemQuantityFieldKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            newPurchases();
            if(sariSariQuantityMap.size()!= 0){
            loadSariSariMethod();
        }
        }
    }//GEN-LAST:event_itemQuantityFieldKeyPressed

    private void itemBoxKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemBoxKeyPressed
        // TODO add your handling code here:
         if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            itemQuantityField.requestFocus();
        }
    }//GEN-LAST:event_itemBoxKeyPressed

    private void depositQuantityFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_depositQuantityFieldKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            addDepositMethod();
        }
    }//GEN-LAST:event_depositQuantityFieldKeyPressed

    private void discountQuantityFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_discountQuantityFieldKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            addDiscountMethod();
        }
    }//GEN-LAST:event_discountQuantityFieldKeyPressed

    private void discountPricePerKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_discountPricePerKeyPressed
        // TODO add your handling code here
        if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            discountQuantityField.requestFocus();
        }
    }//GEN-LAST:event_discountPricePerKeyPressed

    private void shellFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shellFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_shellFieldActionPerformed

    private void botFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botFieldActionPerformed

    private void textField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField3ActionPerformed

    private void fcFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fcFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fcFieldActionPerformed

    private void formulaFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_formulaFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_formulaFieldActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) customerTable.getModel();
        EditExcelDeposit ed = new EditExcelDeposit();
        
        int selectedRow = (int) customerTable.getSelectedRow();
        String editSelected = customerTable.getModel().getValueAt(selectedRow, 0).toString();
        
        String bot = botField.getText();
        String shell = shellField.getText();
        String fc = fcField.getText();
        String formula = formulaField.getText();
        int cusRow = customerPurchases.get(editSelected);
        
        ed.editDeposit(cusRow, bot, shell, fc, formula);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void itemQuantityFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_itemQuantityFieldFocusGained
        // TODO add your handling code here:
        if(itemQuantityField.getText().equals("Quantity")){
            itemQuantityField.setText(null);
            itemQuantityField.requestFocus();
            
            removePlaceHolder(itemQuantityField);
        }
    }//GEN-LAST:event_itemQuantityFieldFocusGained

    private void itemQuantityFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemQuantityFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemQuantityFieldActionPerformed

    private void itemQuantityFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_itemQuantityFieldFocusLost
        // TODO add your handling code here:
        if(itemQuantityField.getText().length()==0){
            addPlaceHolder(itemQuantityField);
            itemQuantityField.setText("Quantity");
        }
    }//GEN-LAST:event_itemQuantityFieldFocusLost

    private void depositQuantityFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_depositQuantityFieldFocusGained
        // TODO add your handling code here:
        if(depositQuantityField.getText().equals("Quantity")){
            depositQuantityField.setText(null);
            depositQuantityField.requestFocus();
            
            removePlaceHolder(depositQuantityField);
        }
    }//GEN-LAST:event_depositQuantityFieldFocusGained

    private void depositQuantityFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_depositQuantityFieldFocusLost
        // TODO add your handling code here:
        if(depositQuantityField.getText().length()==0){
            addPlaceHolder(depositQuantityField);
            depositQuantityField.setText("Quantity");
        }
    }//GEN-LAST:event_depositQuantityFieldFocusLost

    private void discountQuantityFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discountQuantityFieldFocusGained
        // TODO add your handling code here:
        if(discountQuantityField.getText().equals("Quantity")){
            discountQuantityField.setText(null);
            discountQuantityField.requestFocus();
            
            removePlaceHolder(discountQuantityField);
        }
    }//GEN-LAST:event_discountQuantityFieldFocusGained

    private void discountQuantityFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discountQuantityFieldFocusLost
        // TODO add your handling code here:
        if(discountQuantityField.getText().length()==0){
            addPlaceHolder(discountQuantityField);
            discountQuantityField.setText("Quantity");
        }
    }//GEN-LAST:event_discountQuantityFieldFocusLost

    private void sariSariQuantityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sariSariQuantityFocusGained
        // TODO add your handling code here:
        if(sariSariQuantity.getText().equals("Quantity")){
            sariSariQuantity.setText(null);
            sariSariQuantity.requestFocus();
            
            removePlaceHolder(sariSariQuantity);
        }
        
    }//GEN-LAST:event_sariSariQuantityFocusGained

    private void sariSariQuantityFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sariSariQuantityFocusLost
        // TODO add your handling code here:
        if(sariSariQuantity.getText().length()==0){
            addPlaceHolder(sariSariQuantity);
            sariSariQuantity.setText("Quantity");
        }
    }//GEN-LAST:event_sariSariQuantityFocusLost

    private void discountPricePerFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discountPricePerFocusGained
        // TODO add your handling code here:
        if(discountPricePer.getText().equals("Discount Unit Price")){
            discountPricePer.setText(null);
            discountPricePer.requestFocus();
            
            removePlaceHolder(discountPricePer);
        }
    }//GEN-LAST:event_discountPricePerFocusGained

    private void discountPricePerFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discountPricePerFocusLost
        // TODO add your handling code here:
        if(discountPricePer.getText().length()==0){
            addPlaceHolder(discountPricePer);
            discountPricePer.setText("Discount Unit Price");
        }
    }//GEN-LAST:event_discountPricePerFocusLost

    private void sariSariUnitPriceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sariSariUnitPriceFocusGained
        // TODO add your handling code here:
        if(sariSariUnitPrice.getText().equals("Sari Sari Unit Price")){
            sariSariUnitPrice.setText(null);
            sariSariUnitPrice.requestFocus();
            
            removePlaceHolder(sariSariUnitPrice);
        }
    }//GEN-LAST:event_sariSariUnitPriceFocusGained

    private void sariSariUnitPriceFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sariSariUnitPriceFocusLost
        // TODO add your handling code here:
        if(sariSariUnitPrice.getText().length()==0){
            addPlaceHolder(sariSariUnitPrice);
            sariSariUnitPrice.setText("Sari Sari Unit Price");
        }
    }//GEN-LAST:event_sariSariUnitPriceFocusLost

    private void sariSariItemNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sariSariItemNameFocusGained
        // TODO add your handling code here:
        if(sariSariItemName.getText().equals("Sari Sari Item Name")){
            sariSariItemName.setText(null);
            sariSariItemName.requestFocus();
            
            removePlaceHolder(sariSariItemName);
        }
    }//GEN-LAST:event_sariSariItemNameFocusGained

    private void sariSariItemNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_sariSariItemNameFocusLost
        // TODO add your handling code here:
        if(sariSariItemName.getText().length()==0){
            addPlaceHolder(sariSariItemName);
            sariSariItemName.setText("Sari Sari Item Name");
        }
    }//GEN-LAST:event_sariSariItemNameFocusLost

    private void addSariSariBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSariSariBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        model.setRowCount(0);
        if(newPurchases.size()!=0){
            loadNewPurchases();
        }
        addSariSariMethod();
    }//GEN-LAST:event_addSariSariBtnActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        // TODO add your handling code here:
        try{
            SetRowSelected sr = new SetRowSelected();
        sr.rowSelect("min", Objects.requireNonNull(deliveryPickupComboBox.getSelectedItem().toString()));
        EmptyRowFinder ef = new EmptyRowFinder(sr.getIndex());
        
        createReceipt(ef.getEmptyRow());
        closeReceipt();
        printReceipt();
        
        int confirmation;
        
        confirmation = JOptionPane.showConfirmDialog(null, "Post to Excel?", "Confirmation", JOptionPane.YES_NO_OPTION);
        
        if (confirmation == 0) {
            closeTransaction();
            closeTransactionBtn.setEnabled(false);
         }
        else{
            closeTransactionBtn.setEnabled(true);
        }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "No item to print");
        }
        
    }//GEN-LAST:event_printButtonActionPerformed
    public void closeTransaction(){
        inputToExcel();
            DefaultTableModel model = (DefaultTableModel) customerTable.getModel();
            model.setRowCount(0);
            loadCustomerNames();
            System.out.println(customerPurchases);
            setAndClear();
    }
    public void setAndClear(){
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        DefaultTableModel depModel = (DefaultTableModel) depositTable.getModel();
        DefaultTableModel discModel = (DefaultTableModel) discountTable.getModel();
        
        newPurchases.clear();
        discountQuantity.clear();
        discountPricePerItem.clear();
        depositItem.clear();
        depositType.clear();
        sariSariQuantityMap.clear();
        sariSariUnitPriceMap.clear();
        printTextPane.setText("");
        totalInvoice.setText("");
        
        model.setRowCount(0);
        depModel.setRowCount(0);
        discModel.setRowCount(0);
        closeTransactionBtn.setEnabled(false);
    }
    private void itemBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_itemBoxItemStateChanged
        // TODO add your handling code here:
         if (evt.getSource() == itemBox) {
                if (Objects.requireNonNull(itemBox.getSelectedItem()).toString().equals("None Selected")) {
                    System.out.println("None Selected");
                } else {
                    java.util.Timer timer = new Timer();

                    TimerTask task = new TimerTask() {
                        @Override
                        public void run() {
                            
                            itemQuantityField.requestFocus();
                        }
                    };
                    timer.schedule(task, 1000);
                }
            } 
    }//GEN-LAST:event_itemBoxItemStateChanged

    private void sariSariQuantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sariSariQuantityKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            if(!newPurchases.isEmpty()){
            loadNewPurchases();
        }
        addSariSariMethod();
        }
    }//GEN-LAST:event_sariSariQuantityKeyPressed

    private void sariSariItemNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sariSariItemNameKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            sariSariUnitPrice.requestFocus();
        }
    }//GEN-LAST:event_sariSariItemNameKeyPressed

    private void sariSariUnitPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sariSariUnitPriceKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyChar()==java.awt.event.KeyEvent.VK_ENTER){
            sariSariQuantity.requestFocus();
        }
    }//GEN-LAST:event_sariSariUnitPriceKeyPressed

    private void closeTransactionBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeTransactionBtnActionPerformed
        // TODO add your handling code here:
        closeTransaction();
    }//GEN-LAST:event_closeTransactionBtnActionPerformed

    private void deleteCusDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteCusDataActionPerformed
        // TODO add your handling code here:
        try{
            deleteExcelRow();
            DefaultTableModel cusModel = (DefaultTableModel) customerPurchaseListTable.getModel();
            cusModel.setRowCount(0);
        }
        catch(ArrayIndexOutOfBoundsException e){
            JOptionPane.showMessageDialog(null, "All Deleted.");
        }
    }//GEN-LAST:event_deleteCusDataActionPerformed

    private void editPurchasesBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editPurchasesBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel cusModel = (DefaultTableModel) customerPurchaseListTable.getModel();
        DefaultTableModel model = (DefaultTableModel) customerTable.getModel();
        ModifyExcelFrom mf = new ModifyExcelFrom();
        
        for(int i = 0; i< cusModel.getRowCount()-1; i++){
            String itemName = cusModel.getValueAt(i, 0).toString();
            double quantity = Double.parseDouble( cusModel.getValueAt(i, 1).toString());
            
            mf.setMap(items, itemName, quantity);
        }
        items = mf.getModifiedItems();
        String customerName = model.getValueAt(customerTable.getSelectedRow(), 0).toString();
        int row = customerPurchases.get(customerName);
        String deliveryPickup = Objects.requireNonNull(deliveryPickupComboBox.getSelectedItem().toString());
        ExcelInput ei = new ExcelInput();
        ei.inputToExcel(row, customerName, deliveryPickup, items);
        
        
    }//GEN-LAST:event_editPurchasesBtnActionPerformed

    private void depositComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_depositComboBoxItemStateChanged
        // TODO add your handling code here:
        depositQuantityField.requestFocus();
    }//GEN-LAST:event_depositComboBoxItemStateChanged

    private void caseShellBotItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_caseShellBotItemStateChanged
        // TODO add your handling code here:
        depositQuantityField.requestFocus();
    }//GEN-LAST:event_caseShellBotItemStateChanged

    private void discountComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_discountComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_discountComboBoxActionPerformed
    
    public void deleteExcelRow(){
        DeleteCustomerData cs = new DeleteCustomerData();
        DefaultTableModel model = (DefaultTableModel) customerTable.getModel();
        int selectedRow = customerTable.getSelectedRow();
        
        String cusName = model.getValueAt(selectedRow, 0).toString();
        
        cs.deleteRow(customerPurchases.get(cusName));
        customerPurchases.remove(cusName);
        model.removeRow(selectedRow);
    }
    public void addSariSariMethod(){
        try{
        double quantity = Double.parseDouble(sariSariQuantity.getText());
        double unitPrice = Double.parseDouble(sariSariUnitPrice.getText());
        String cusName = "Sri" + sariSariItemName.getText();
        
        sariSariQuantityMap.put(cusName, quantity);
        sariSariUnitPriceMap.put(cusName, unitPrice);
        
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        //model.setRowCount(0);
        
        loadSariSariMethod();
        getTotalCashAmount();
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Type an appropriate number", "Error", JOptionPane.WARNING_MESSAGE);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong...", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    public void loadSariSariMethod(){
        DefaultTableModel model = (DefaultTableModel) purchaseListTable.getModel();
        
        //reused the calculation for the final price of discount because it is reusable, this is sari sari item adder.
        for(String i : sariSariQuantityMap.keySet()){
            
            CalculateDiscountPrice cs = new CalculateDiscountPrice(sariSariQuantityMap.get(i), sariSariUnitPriceMap.get(i));
             Object[] tb = {i, sariSariQuantityMap.get(i), cs.getTotalDiscount()};
             model.addRow(tb);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(POSFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(POSFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(POSFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(POSFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new POSFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addDepositButton;
    private javax.swing.JButton addDiscountBtn;
    private javax.swing.JButton addItemButton;
    private javax.swing.JButton addSariSariBtn;
    private java.awt.TextField botField;
    private javax.swing.JComboBox<String> caseShellBot;
    private javax.swing.JButton cashButton;
    private javax.swing.JButton changeTabButton;
    private javax.swing.JButton changeTabButtonTab1;
    private javax.swing.JButton closeTransactionBtn;
    private javax.swing.JTable customerPurchaseListTable;
    public javax.swing.JTable customerTable;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton deleteCusData;
    public javax.swing.JComboBox<String> deliveryPickupComboBox;
    private javax.swing.JComboBox<String> depositComboBox;
    private java.awt.TextField depositQuantityField;
    private javax.swing.JTable depositTable;
    private javax.swing.JComboBox<String> discountComboBox;
    private java.awt.TextField discountPricePer;
    private java.awt.TextField discountQuantityField;
    private javax.swing.JTable discountTable;
    private javax.swing.JButton editPurchasesBtn;
    private java.awt.TextField fcField;
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler2;
    private javax.swing.Box.Filler filler3;
    private java.awt.TextField formulaField;
    private javax.swing.JComboBox<String> itemBox;
    private java.awt.TextField itemQuantityField;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane posTab;
    private javax.swing.JButton printButton;
    private javax.swing.JTextPane printTextPane;
    private javax.swing.JTable purchaseListTable;
    private javax.swing.JTextField receiptName;
    private java.awt.TextField sariSariItemName;
    private java.awt.TextField sariSariQuantity;
    private java.awt.TextField sariSariUnitPrice;
    public java.awt.TextField selectedFile;
    private java.awt.TextField shellField;
    private java.awt.TextField textField3;
    private javax.swing.JTextField totalField;
    private javax.swing.JTextField totalInvoice;
    // End of variables declaration//GEN-END:variables
}
