
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class SetSelectedFile {
    private String filePath = "";

    public String getFilePath() {
        String fileDirectory = "C:/Users/skepp/Desktop/filedirectory.xlsx";

        try {
            FileInputStream inputStream = new FileInputStream(fileDirectory);

            Workbook workbook = WorkbookFactory.create(inputStream);

            Sheet sheet = workbook.getSheetAt(0);

            Row row = sheet.getRow(0);
            Cell cell = row.getCell(0);

            filePath = cell.toString();


            FileOutputStream outputStream = new FileOutputStream(fileDirectory);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return filePath;
    }
    
}
