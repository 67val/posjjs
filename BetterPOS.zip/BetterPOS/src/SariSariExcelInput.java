
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class SariSariExcelInput {
        SetSelectedFile sf = new SetSelectedFile();
        String excelFilePath = sf.getFilePath();
        public void excelInputSariSari(HashMap<String, Double> sriItems,HashMap<String, Double> sriPricePer, int rowSelected){
        try{
            FileInputStream inputStream = new FileInputStream(excelFilePath);
                    Workbook workbook = WorkbookFactory.create(inputStream);

                    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

                    Sheet sheet = workbook.getSheetAt(0);


                    //A switch case will be added for all ComboBoxes

                    CellStyle style = workbook.createCellStyle();
                    style.setBorderBottom(BorderStyle.THIN);
                    style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                    style.setBorderRight(BorderStyle.THIN);
                    style.setRightBorderColor(IndexedColors.BLACK.getIndex());
                    style.setBorderTop(BorderStyle.THIN);
                    style.setTopBorderColor(IndexedColors.BLACK.getIndex());
                    style.setBorderLeft(BorderStyle.THIN);
                    style.setTopBorderColor(IndexedColors.BLACK.getIndex());
                    
                    
                    for(String i : sriItems.keySet()){
                            String sariSariCheck = i.substring(0, 3);
                            int index = 0;

                            if (sariSariCheck.equals("Sri")) {

                                int theRowSelected = rowSelected;
                                Row readRowSelected = sheet.getRow(rowSelected);
                                Cell readCellSelected = readRowSelected.getCell(1);

                                if (readCellSelected != null) {
                                    while (index == 0) {
                                        Row readRow = sheet.getRow(theRowSelected);
                                        Cell readCell = readRow.getCell(1);

                                        if (readCell.toString().isEmpty()) {
                                            index = 1;
                                        } else {
                                            theRowSelected++;
                                        }
                                    }
                                }


                                Row r0 = sheet.getRow(theRowSelected);
                                Cell c0 = r0.createCell(1);
                                c0.setCellStyle(style);
                                c0.setCellValue(i);

                                Row r3 = sheet.getRow(theRowSelected);
                                Cell cell1 = r3.getCell(62);
                                

                                if (cell1.toString().isEmpty()) {
                                    Cell cell3 = r3.createCell(62);
                                    cell3.setCellStyle(style);
                                    cell3.setCellFormula("+" + (sriItems.get(i)*sriPricePer.get(i)));
                                } else {
                                    Cell cell0 = r3.getCell(62);
                                    cell1.setCellStyle(style);
                                    cell1.setCellFormula(cell0 + "+" + (sriItems.get(i)*sriPricePer.get(i)));
                                }
                                evaluator.evaluateAll();
                            }
                    }
            
                    inputStream.close();
                    FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                    workbook.write(outputStream);
                    workbook.close();
                    outputStream.close();
        }
        catch(IOException | EncryptedDocumentException ex){
            ex.printStackTrace();
        }
    }
}
