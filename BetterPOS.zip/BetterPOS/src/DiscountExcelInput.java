
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class DiscountExcelInput {
    public void discountInput(HashMap<String, Double> discountQuantity, HashMap<String, Double> discountUnit, int rowSelected){
        try{
            SetSelectedFile sf = new SetSelectedFile();
            String excelFilePath = sf.getFilePath();
            FileInputStream inputStream = new FileInputStream(excelFilePath);
            Workbook workbook = WorkbookFactory.create(inputStream);

            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

            Sheet sheet = workbook.getSheetAt(0);

                    //A switch case will be added for all ComboBoxes
            CellStyle style2 = workbook.createCellStyle();
            style2.setBorderBottom(BorderStyle.THIN);
            style2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style2.setBorderRight(BorderStyle.THIN);
            style2.setRightBorderColor(IndexedColors.BLACK.getIndex());
            style2.setBorderTop(BorderStyle.THIN);
            style2.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style2.setBorderLeft(BorderStyle.THIN);
            style2.setLeftBorderColor(IndexedColors.BLACK.getIndex());
            
            Row row = sheet.getRow(rowSelected);
            Cell cell = row.getCell(63);
            
            for(String i : discountQuantity.keySet()){
                    if (cell.toString() != null) {
                    cell.setCellStyle(style2);
                    cell.setCellFormula(cell + "-" + (discountQuantity.get(i) * discountUnit.get(i)));
            } 
                else{
                    Cell cellCreate = row.createCell(63);
                    cellCreate.setCellStyle(style2);
                    cellCreate.setCellFormula("-" + (discountQuantity.get(i) *discountUnit.get(i)));
               }
            }
            
            evaluator.evaluateAll();

            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
        }
        catch(IOException | EncryptedDocumentException ex){
            ex.printStackTrace();
        }
    }
}
