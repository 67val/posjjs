
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class GetCustomerPurchases {
    private HashMap<String, Double> items = new HashMap<>();
    
    public void setItems(int rowNumber){

        SetSelectedFile sf = new SetSelectedFile();
        String excelFilePath = sf.getFilePath();
        try {

            FileInputStream inputStream = new FileInputStream(excelFilePath);
            Workbook workbook = WorkbookFactory.create(inputStream);


            Sheet sheet = workbook.getSheetAt(0);


            Row readRow = sheet.getRow(rowNumber);
            Cell cell100 = readRow.getCell(1);
            if (cell100.toString().isEmpty()) {
                System.out.println("hi");
            } else {
                for (int i = 4; i < 50; i++) {
                    Cell cell1 = readRow.getCell(i);

                    if (!cell1.toString().isEmpty()) {

                        switch (i) {
                            
                            case 5 -> items.put("Cobra Y/G", Double.valueOf(cell1.toString()));
                            case 6 -> items.put("8Oz", Double.valueOf(cell1.toString()));
                            //case 7 -> nonNullData.add("Coke 8Oz");
                            case 8 -> items.put("12Oz", Double.valueOf(cell1.toString()));
                            //case 9 -> nonNullData.add("Sakto: " + cell1);
                            case 10 -> items.put("Sparkle", Double.valueOf(cell1.toString()));
                            case 11 -> items.put("Rc", Double.valueOf(cell1.toString()));
                            case 12 -> items.put("Lemon", Double.valueOf(cell1.toString()));
                            case 13 -> items.put("MDW - 12Oz", Double.valueOf(cell1.toString()));
                            case 14 -> items.put("Gatorade", Double.valueOf(cell1.toString()));
                            case 15 -> items.put("Pepsi", Double.valueOf(cell1.toString()));
                            case 16 -> items.put("MDW-8Oz", Double.valueOf(cell1.toString()));
                            case 17 -> items.put("Magnolia", Double.valueOf(cell1.toString()));
                            case 18 -> items.put("Mismo", Double.valueOf(cell1.toString()));
                            case 19 -> items.put("Swakto", Double.valueOf(cell1.toString()));
                            case 20 -> items.put("Minute-Maid", Double.valueOf(cell1.toString()));
                            case 21 -> items.put("C2", Double.valueOf(cell1.toString()));
                            case 22 -> items.put("V-Shake", Double.valueOf(cell1.toString()));
                            case 23 -> items.put("Vita", Double.valueOf(cell1.toString()));
                            case 24 -> items.put("Pepsi Litro", Double.valueOf(cell1.toString()));
                            case 25 -> items.put("Litro", Double.valueOf(cell1.toString()));
                            case 26 -> items.put("7UP/MDW LITRO", Double.valueOf(cell1.toString()));
                            case 27 -> items.put("J5", Double.valueOf(cell1.toString()));
                            case 28 -> items.put("Kasalo", Double.valueOf(cell1.toString()));
                            case 29 -> items.put("R2", Double.valueOf(cell1.toString()));
                            case 30 -> items.put("T-ICE", Double.valueOf(cell1.toString()));
                            case 31 -> items.put("J2", Double.valueOf(cell1.toString()));
                            case 32 -> items.put("Jumbo", Double.valueOf(cell1.toString()));
                            case 33 -> items.put("Grande", Double.valueOf(cell1.toString()));
                            case 34 -> items.put("RH-500", Double.valueOf(cell1.toString()));
                            case 35 -> items.put("Stallion", Double.valueOf(cell1.toString()));
                            case 36 -> items.put("Pilsen", Double.valueOf(cell1.toString()));
                            case 37 -> items.put("SML", Double.valueOf(cell1.toString()));
                            case 38 -> items.put("Flavored", Double.valueOf(cell1.toString()));
                            case 39 -> items.put("Jamaica", Double.valueOf(cell1.toString()));
                            case 40 -> items.put("T65 - Flat", Double.valueOf(cell1.toString()));
                            case 41 -> items.put("5YRS Flat", Double.valueOf(cell1.toString()));
                            case 42 -> items.put("T65 Long", Double.valueOf(cell1.toString()));
                            case 43 -> items.put("5-YRS Long", Double.valueOf(cell1.toString()));
                            case 44 -> items.put("1.5L", Double.valueOf(cell1.toString()));
                            case 45 -> items.put("1.25L", Double.valueOf(cell1.toString()));
                            
                            case 46 -> items.put("Astig", Double.valueOf(cell1.toString()));
                            
                            case 47 -> items.put("QUTE", Double.valueOf(cell1.toString()));
                            case 48 -> items.put("W-330", Double.valueOf(cell1.toString()));
                            case 49 -> items.put("W-500", Double.valueOf(cell1.toString()));
                            case 50 -> items.put("AB-6000", Double.valueOf(cell1.toString()));
                            case 51 -> items.put("W-7000", Double.valueOf(cell1.toString()));
                            //case 50-> nonNullData.add("8Oz: " + cell1);

                        }
                    }
                }
            }
            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();

            //System.out.println("CODEx100100: ROW SELECTED = 2");


        } catch (IOException | EncryptedDocumentException ex) {
            ex.printStackTrace();
        }
    }
    public HashMap<String, Double> getItemsList(){
        return items;
    }
 }
