
import java.util.HashMap;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class ModifyExcelFrom {
    private HashMap<String,Double> items;
    
    public void setMap(HashMap<String,Double> items, String itemName, double quantity){
        this.items = items;
        items.put(itemName, quantity);
    }
    public HashMap<String,Double> getModifiedItems(){
        return items;
    }
}
