
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class EditExcelDeposit {
    public void editDeposit(int editSelected, String botValue, String shellValue, String fcValue, String formula){
        SetSelectedFile sf = new SetSelectedFile();
        String excelFilePath = sf.getFilePath();
        try {
            FileInputStream inputStream = new FileInputStream(excelFilePath);
            Workbook workbook = WorkbookFactory.create(inputStream);

            Sheet sheet = workbook.getSheetAt(0);

            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

            CellStyle style2 = workbook.createCellStyle();
            style2.setBorderBottom(BorderStyle.THIN);
            style2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style2.setBorderRight(BorderStyle.THIN);
            style2.setRightBorderColor(IndexedColors.BLACK.getIndex());
            style2.setBorderTop(BorderStyle.THIN);
            style2.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style2.setBorderLeft(BorderStyle.THIN);
            style2.setLeftBorderColor(IndexedColors.BLACK.getIndex());

            Row row = sheet.getRow(editSelected);
            Cell cellBot = row.getCell(58);
            cellBot.setCellFormula(botValue);

            Cell cellShell = row.getCell(57);
            cellShell.setCellFormula(shellValue);

            Cell cellFC = row.getCell(56);
            cellFC.setCellFormula(fcValue);

            Cell cellFormula = row.getCell(59);
            cellFormula.setCellFormula(formula);
            evaluator.evaluateAll();

            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
