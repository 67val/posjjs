
import java.util.Locale;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class SetRowSelected {
    private int index = 0;
    private int indexMax = 0;
    
    
    private SetSelectedFile sf = new SetSelectedFile();
    //private String filePath = sf.getFilePath();
    
    public void rowSelect(String minOrMax, String purchaseType){
       

            //A switch case will be added for all ComboBoxes
            
            
            if(minOrMax.toLowerCase(Locale.ITALY).equals("max")){ // This switch case returns max value
                switch (purchaseType.toLowerCase()) {
                case "pickup" ->{ 
                        indexMax = 150;
                        
                        }

                case "chito" ->{
                    indexMax = 250; // max value
                     // min value
                }
                case "willy" -> {
                
                     indexMax = 350;
                }
                case "nicanor" ->{
                    indexMax = 450;
                    
                }

                default -> System.out.println("no");
            }
        }
            else{
                switch (purchaseType.toLowerCase()) { //This switch case returns min value
                case "pickup" ->{ 
                        
                        index = 2;
                        }

                case "chito" ->{
                    
                    index = 150; // min value
                }
                case "willy" -> {
                index = 250;
                
                }
                case "nicanor" ->{
                    
                    index = 350;
                }

                default -> System.out.println("no");
                }
            }
      }
    public int getIndex(){
        return index;
    }
    public int getIndexMax(){
        return indexMax;
    }
}
