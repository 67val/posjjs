/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelPrices {

    int sparkle;
    int eightOz;
    int cobra;
    int cobraRed;
    int twelveOz;
    int rc;
    int lemon;
    int mdw12Oz;
    int gatorade;
    int pepsi;
    int mdw8oz;
    int magnolia;
    int mismo;
    int swakto;
    int minuteMaid;
    int c2price;
    int vshake;
    int vchoco;
    int pepsiLitro;
    int litro;
    int sevenUp;
    int j5;
    int kasalo;
    int r2;
    int tice;
    int lemonMega;
    int jumbo;
    int grande;
    int rh500;
    int stallion;
    int pilsen;
    int light;
    int lightFlavored;
    int jamaica;
    int t65Flat;
    int fiveYrsFlat;
    int t65Long;
    int fiveYrsLong;
    int onePointFiveLiters;
    int qute;
    int w330;
    int w500;
    int ab6000;
    int w6000;
    int point25;
    int astig;
    public void priceSetter(){
        String fileDirectory = "C:/Users/skepp/Desktop/filedirectory.xlsx";

        try {

            FileInputStream inputStream = new FileInputStream(fileDirectory);

            Workbook workbook = WorkbookFactory.create(inputStream);

            Sheet sheet = workbook.getSheetAt(1);

            int cellInt = 2;

            //cobra
            Row sparkleRow = sheet.getRow(1);
            Cell sparkleCell = sparkleRow.getCell(cellInt);
            sparkle = (int) sparkleCell.getNumericCellValue();

            Row eightOzRow = sheet.getRow(0);
            Cell eightOzCell = eightOzRow.getCell(cellInt);
            eightOz = (int) eightOzCell.getNumericCellValue();

            Row cobraRow = sheet.getRow(3-1);
            Cell cobraCell = cobraRow.getCell(cellInt);
            cobra = (int) cobraCell.getNumericCellValue();

            Row cobraRedRow = sheet.getRow(4-1);
            Cell cobraRedCell = cobraRedRow.getCell(cellInt);
            cobraRed = (int) cobraRedCell.getNumericCellValue();

            Row twelveOzRow = sheet.getRow(5-1);
            Cell twelveOzCell = twelveOzRow.getCell(cellInt);
            twelveOz = (int) twelveOzCell.getNumericCellValue();

            Row rcRow = sheet.getRow(6-1);
            Cell rcCell = rcRow.getCell(cellInt);
            rc = (int) rcCell.getNumericCellValue();

            Row lemonRow = sheet.getRow(7-1);
            Cell lemonCell = lemonRow.getCell(cellInt);
            lemon = (int) lemonCell.getNumericCellValue();

            Row mdw12ozRow = sheet.getRow(8-1);
            Cell mdw12ozCell = mdw12ozRow.getCell(cellInt);
            mdw12Oz = (int) mdw12ozCell.getNumericCellValue();

            Row gatoradeRow = sheet.getRow(9-1);
            Cell gatoradeCell = gatoradeRow.getCell(cellInt);
            gatorade = (int) gatoradeCell.getNumericCellValue();

            Row pepsiRow = sheet.getRow(10-1);
            Cell pepsiCell = pepsiRow.getCell(cellInt);
            pepsi = (int) pepsiCell.getNumericCellValue();

            Row mdw8ozRow = sheet.getRow(11-1);
            Cell mdw8ozCell =mdw8ozRow.getCell(cellInt);
            mdw8oz = (int) mdw8ozCell.getNumericCellValue();

            Row magnoliaRow = sheet.getRow(12-1);
            Cell magnoliaCell = magnoliaRow.getCell(cellInt);
            magnolia = (int) magnoliaCell.getNumericCellValue();

            Row mismoRow = sheet.getRow(13-1);
            Cell mismoCell = mismoRow.getCell(cellInt);
            mismo = (int) mismoCell.getNumericCellValue();

            Row swaktoRow= sheet.getRow(14-1);
            Cell swaktoCell = swaktoRow.getCell(cellInt);
            swakto = (int) swaktoCell.getNumericCellValue();

            Row minuteMaidRow = sheet.getRow(15-1);
            Cell minuteMaidCell = minuteMaidRow.getCell(cellInt);
            minuteMaid = (int) minuteMaidCell.getNumericCellValue();

            Row c2PriceRow = sheet.getRow(16-1);
            Cell c2PriceCell = c2PriceRow.getCell(cellInt);
            c2price = (int) c2PriceCell.getNumericCellValue();

            Row vshakeRow = sheet.getRow(17-1);
            Cell vshakeCell = vshakeRow.getCell(cellInt);
            vshake = (int) vshakeCell.getNumericCellValue();

            Row vchocoRow = sheet.getRow(18-1);
            Cell vchocoCell = vchocoRow.getCell(cellInt);
            vchoco = (int) vchocoCell.getNumericCellValue();

            Row pepsiLitroRow = sheet.getRow(19-1);
            Cell pepsiLitroCell = pepsiLitroRow.getCell(cellInt);
            pepsiLitro = (int) pepsiLitroCell.getNumericCellValue();

            Row litroRow = sheet.getRow(20-1);
            Cell litroCell = litroRow.getCell(cellInt);
            litro = (int) litroCell.getNumericCellValue();

            Row sevenUpRow = sheet.getRow(21-1);
            Cell sevenUpCell = sevenUpRow.getCell(cellInt);
            sevenUp = (int) sevenUpCell.getNumericCellValue();

            Row j5Row = sheet.getRow(22-1);
            Cell j5Cell = j5Row.getCell(cellInt);
            j5 = (int) j5Cell.getNumericCellValue();

            Row kasaloRow = sheet.getRow(23-1);
            Cell kasaloCell = kasaloRow.getCell(cellInt);
            kasalo = (int) kasaloCell.getNumericCellValue();

            Row r2Row = sheet.getRow(24-1);
            Cell r2Cell = r2Row.getCell(cellInt);
            r2 = (int) r2Cell.getNumericCellValue();

            Row ticeRow = sheet.getRow(25-1);
            Cell ticeCell = ticeRow.getCell(cellInt);
            tice = (int) ticeCell.getNumericCellValue();

            Row lemonMegaRow= sheet.getRow(26-1);
            Cell lemonMegaCell = lemonMegaRow.getCell(cellInt);
            lemonMega = (int) lemonMegaCell.getNumericCellValue();

            Row jumboRow = sheet.getRow(27-1);
            Cell jumboCell = jumboRow.getCell(cellInt);
            jumbo = (int) jumboCell.getNumericCellValue();

            Row grandeRow = sheet.getRow(28-1);
            Cell grandeCell = grandeRow.getCell(cellInt);
            grande = (int) grandeCell.getNumericCellValue();

            Row rh500Row = sheet.getRow(29-1);
            Cell rh500Cell = rh500Row.getCell(cellInt);
            rh500 = (int) rh500Cell.getNumericCellValue();

            Row stallionRow = sheet.getRow(30-1);
            Cell stallionRowCell = stallionRow.getCell(cellInt);
            stallion = (int) stallionRowCell.getNumericCellValue();

            Row pilsenRow = sheet.getRow(31-1);
            Cell pilsenCell = pilsenRow.getCell(cellInt);
            pilsen = (int) pilsenCell.getNumericCellValue();

            Row lightRow = sheet.getRow(32-1);
            Cell lightCell = lightRow.getCell(cellInt);
            light = (int) lightCell.getNumericCellValue();

            Row lightFlavoredRow = sheet.getRow(33-1);
            Cell lightFlavoredCell = lightFlavoredRow.getCell(cellInt);
            lightFlavored = (int) lightFlavoredCell.getNumericCellValue();

            Row jamaicaRow = sheet.getRow(34-1);
            Cell jamaicaCell = jamaicaRow.getCell(cellInt);
            jamaica = (int) jamaicaCell.getNumericCellValue();

            Row t65FlatRow = sheet.getRow(35-1);
            Cell t65FlatCell = t65FlatRow.getCell(cellInt);
            t65Flat = (int) t65FlatCell.getNumericCellValue();

            Row fiveYrsFlatRow = sheet.getRow(36-1);
            Cell fiveYrsFlatCell = fiveYrsFlatRow.getCell(cellInt);
            fiveYrsFlat = (int) fiveYrsFlatCell.getNumericCellValue();

            Row t65LongRow = sheet.getRow(37-1);
            Cell t65LongCell = t65LongRow.getCell(cellInt);
            t65Long = (int) t65LongCell.getNumericCellValue();

            Row fiveYrsLongRow = sheet.getRow(38-1);
            Cell fiveYrsLongCell = fiveYrsLongRow.getCell(cellInt);
            fiveYrsLong = (int) fiveYrsLongCell.getNumericCellValue();

            Row onePointFiveLitersRow = sheet.getRow(39-1);
            Cell onePointFiveLitersCell = onePointFiveLitersRow.getCell(cellInt);
            onePointFiveLiters = (int) onePointFiveLitersCell.getNumericCellValue();

            Row quteRow = sheet.getRow(40-1);
            Cell quteCell = quteRow.getCell(cellInt);
            qute = (int) quteCell.getNumericCellValue();

            Row w330Row = sheet.getRow(41-1);
            Cell w330Cell = w330Row.getCell(cellInt);
            w330 = (int) w330Cell.getNumericCellValue();

            Row w500Row = sheet.getRow(42-1);
            Cell w500Cell = w500Row.getCell(cellInt);
            w500 = (int) w500Cell.getNumericCellValue();

            Row ab6000Row = sheet.getRow(43-1);
            Cell ab6000Cell = ab6000Row.getCell(cellInt);
            ab6000= (int) ab6000Cell.getNumericCellValue();

            Row w6000Row = sheet.getRow(44-1);
            Cell w6000Cell = w6000Row.getCell(cellInt);
            w6000 = (int) w6000Cell.getNumericCellValue();
            
            Row point25Row = sheet.getRow(45-1);
            Cell point25Cell = point25Row.getCell(cellInt);
            point25 = (int) point25Cell.getNumericCellValue();
            
            Row astigRow = sheet.getRow(46-1);
            Cell astigCell = astigRow.getCell(cellInt);
            astig = (int) astigCell.getNumericCellValue();


            FileOutputStream outputStream = new FileOutputStream(fileDirectory);
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
