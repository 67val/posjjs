
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;
import javax.swing.JOptionPane;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Samuel Yee
 */
public class DepositExcelInput {
    public void depositInput(HashMap<String, Double> dpQuantity, HashMap<String, String> dpType, int rowSelected, String customerName, String deliveryPickupType){
        try{
            SetSelectedFile sf = new SetSelectedFile();
            String excelFilePath = sf.getFilePath();
            FileInputStream inputStream = new FileInputStream(excelFilePath);
                Workbook workbook = WorkbookFactory.create(inputStream);

                Sheet sheet = workbook.getSheetAt(0);
                CalculateDepositRefund rf = new CalculateDepositRefund();

                //A switch case will be added for all ComboBoxes
                CellStyle style2 = workbook.createCellStyle();
                style2.setBorderBottom(BorderStyle.THIN);
                style2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                style2.setBorderRight(BorderStyle.THIN);
                style2.setRightBorderColor(IndexedColors.BLACK.getIndex());
                style2.setBorderTop(BorderStyle.THIN);
                style2.setTopBorderColor(IndexedColors.BLACK.getIndex());
                style2.setBorderLeft(BorderStyle.THIN);
                style2.setLeftBorderColor(IndexedColors.BLACK.getIndex());

                CellStyle style = workbook.createCellStyle();
                style.setBorderBottom(BorderStyle.THIN);
                style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                style.setBorderRight(BorderStyle.THIN);
                style.setRightBorderColor(IndexedColors.BLACK.getIndex());
                style.setBorderTop(BorderStyle.THIN);
                style.setTopBorderColor(IndexedColors.BLACK.getIndex());
                style.setBorderLeft(BorderStyle.THIN);
                style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
                style.setFillForegroundColor(IndexedColors.PINK.getIndex());
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                
                
                FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

            for (String i : dpQuantity.keySet()) {
                
                
                System.out.println(rowSelected + "LEROWSELECTED");
                
                String[] split = i.split(" ");
                    switch (dpType.get(i).toLowerCase(Locale.ROOT)) {
                        case "bot" -> {
                            Row row = sheet.getRow(rowSelected);
                            Cell cell = row.getCell(59);
                            Cell cell1 = row.getCell(58);
                            rf.depositCalc(dpType.get(i), split[0], dpQuantity.get(i));
                            if (cell.toString().isEmpty()) {
                                Cell cell2 = row.createCell(59);
                                cell2.setCellStyle(style2);
                                cell2.setCellFormula("+" + rf.getTotalPrice());
                            } else {
                                
                                Cell cell0 = row.getCell(59);
                                cell.setCellStyle(style2);
                                cell.setCellFormula(cell0 + "+" + rf.getTotalPrice());
                            }
                            if (cell1.toString().isEmpty()) {
                                Cell cell3 = row.createCell(58);
                                cell3.setCellStyle(style);
                                cell3.setCellFormula("+" + dpQuantity.get(i));
                            } else {
                                Cell cell0 = row.getCell(58);
                                cell1.setCellStyle(style);
                                cell1.setCellFormula(cell0 + "+" + dpQuantity.get(i));
                            }
                        }
                        case "shell" -> {

                            Row row = sheet.getRow(rowSelected);
                            Cell cell = row.getCell(59);
                            Cell cell1 = row.getCell(57);
                            rf.depositCalc(dpType.get(i), split[0], dpQuantity.get(i));
                            if (cell.toString().isEmpty()) {

                                Cell cell2 = row.createCell(59);
                                cell2.setCellStyle(style2);
                                cell2.setCellFormula("+" + rf.getTotalPrice());
                            } else {
                                Cell cell0 = row.getCell(59);
                                cell.setCellStyle(style2);
                                cell.setCellFormula(cell0 + "+" + rf.getTotalPrice());
                            }

                            if (cell1.toString().isEmpty()) {
                                Cell cell3 = row.createCell(57);
                                cell3.setCellStyle(style);
                                cell3.setCellFormula("+" + dpQuantity.get(i));
                            } else {
                                Cell cell0 = row.getCell(57);
                                cell1.setCellStyle(style);
                                cell1.setCellFormula(cell0 + "+" + dpQuantity.get(i));
                            }
                        }
                        case "fc" -> {
                            Row row = sheet.getRow(rowSelected);
                            System.out.println("DEPOSIT ROW SELECTED: " + rowSelected);
                            Cell cell = row.getCell(59);
                            Cell cell1 = row.getCell(56);
                            rf.depositCalc(dpType.get(i), split[0], dpQuantity.get(i));
                            if (cell.toString().isEmpty()) {
                                Cell cell2 = row.createCell(59);
                                cell2.setCellStyle(style2);
                                cell2.setCellFormula("+" + rf.getTotalPrice());

                            } else {
                                Cell cell0 = row.getCell(59);
                                cell.setCellStyle(style2);
                                cell.setCellFormula(cell0 + "+" + rf.getTotalPrice());
                            }
                            if (cell1.toString().isEmpty()) {
                                Cell cell3 = row.createCell(56);
                                cell3.setCellStyle(style);
                                cell3.setCellFormula("+" + dpQuantity.get(i));
                               
                                System.out.println(cell3);
                            } else {
                                cell1 = row.getCell(56);
                                cell1.setCellStyle(style);
                                cell1.setCellFormula(cell1 + "+" + dpQuantity.get(i));

                                System.out.println(i);
                            }
                        }
                        case "ref fc", "ref bot", "ref shell" -> {
                            

                            Row r1 = sheet.getRow(rowSelected);
                            Cell c1 = r1.createCell(1);
                            c1.setCellStyle(style2);
                            c1.setCellValue(customerName + (rowSelected) + "/refund");

                            Row r5 = sheet.getRow(rowSelected);
                            Cell c5 = r5.createCell(3);
                            c5.setCellStyle(style2);
                            c5.setCellValue(deliveryPickupType);


                            Row row = sheet.getRow(rowSelected);
                            
                            Cell cell = row.getCell(60);
                            
                            String[] splits = i.split(" ");
                            
                             rf.depositCalc(dpType.get(i), splits[0], dpQuantity.get(i));
                            if (cell.toString().isEmpty()) {
                                Cell cell2 = row.createCell(60);
                                cell2.setCellStyle(style2);
                                cell2.setCellFormula("" + rf.getTotalPrice());
                            } else {
                                Cell cell0 = row.getCell(60);
                                cell.setCellStyle(style2);
                                cell.setCellFormula(cell0 + "" + rf.getTotalPrice());
                            }
                        }
                        default -> System.out.println("default");
                    }

                }

                evaluator.evaluateAll();
                FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                workbook.write(outputStream);
                workbook.close();
                outputStream.close();

                System.out.println("CODEx100100: ROW SELECTED = 2");
        }
        catch(IOException | EncryptedDocumentException ex){
            ex.printStackTrace();
        }
    }
}

